#pragma once

#define MAX_OBJ_COUNT 100

#define MAX_MAP_X 8
#define MAX_MAP_Y 8

#define HERO_ID 0

#define TYPE_NORMAL 0